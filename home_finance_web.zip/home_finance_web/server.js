const express = require('express');
const ejs = require('ejs');
const { Pool } = require('pg');
const bcrypt = require('bcrypt');
const session = require('express-session');

const app = express();
const port = 3000;

// Настройка подключения к PostgreSQL
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'home_finance_web',
  password: '22081921',
  port: 5432,
});

// Настройка сессий
app.use(session({
  secret: 'your-secret-key', // Секретный ключ для подписи сессии
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false } 
}));

// Middleware для проверки авторизации
const requireLogin = (req, res, next) => {
  if (!req.session.userId) {
    return res.redirect('/login');
  }
  next();
};

// Настройка статических файлов и шаблонизатора
app.use(express.static('public'));
app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true })); // Для обработки данных форм

// Главная страница (только для авторизованных пользователей)
app.get('/', requireLogin, async (req, res) => {
  try {
    // Получаем данные пользователя
    const { rows: user } = await pool.query('SELECT * FROM users WHERE userid = $1', [req.session.userId]);

    // Получаем все транзакции для текущего пользователя
    const { rows: transactions } = await pool.query(
      `SELECT t.*, c.CategoryType 
       FROM Transactions t
       JOIN Categories c ON t.CategoryID = c.CategoryID
       WHERE t.userid = $1
       ORDER BY t.TransactionDate DESC`,
      [req.session.userId]
    );

    // Разделяем транзакции на пополнения и расходы
    const income = transactions.filter(t => t.transactiontype === 'income');
    const expenses = transactions.filter(t => t.transactiontype === 'expense');

    // Рассчитываем общий бюджет
    const totalIncome = income.reduce((sum, t) => sum + parseFloat(t.amount), 0);
    const totalExpenses = expenses.reduce((sum, t) => sum + parseFloat(t.amount), 0);
    const totalBudget = totalIncome - totalExpenses;

    // Получаем данные для графика (сумма по дням)
    const { rows: chartData } = await pool.query(
      `SELECT DATE(t.TransactionDate) AS date, 
              SUM(CASE WHEN t.transactiontype = 'income' THEN t.Amount ELSE 0 END) AS income,
              SUM(CASE WHEN t.transactiontype = 'expense' THEN t.Amount ELSE 0 END) AS expense
       FROM Transactions t
       WHERE t.userid = $1
       GROUP BY DATE(t.TransactionDate)
       ORDER BY date DESC
       LIMIT 7`,
      [req.session.userId]
    );

    // Рендерим страницу с данными
    res.render('index', {
      user: user[0], // Данные пользователя
      income,
      expenses,
      totalBudget: totalBudget.toFixed(2),
      totalIncome: totalIncome.toFixed(2),
      totalExpenses: totalExpenses.toFixed(2),
      chartData,
    });
  } catch (err) {
    console.error('Ошибка при загрузке данных:', err);
    res.status(500).send('Ошибка сервера');
  }
});

// Маршрут для отображения формы добавления бюджета
app.get('/add-budget', requireLogin, async (req, res) => {
  try {
    // Получаем список категорий для выпадающего списка
    const { rows: categories } = await pool.query('SELECT * FROM categories');
    res.render('add-budget', { categories });
  } catch (err) {
    console.error('Ошибка при загрузке категорий:', err);
    res.status(500).send('Ошибка сервера');
  }
});

// Обработка добавления бюджета
app.post('/add-budget', requireLogin, async (req, res) => {
  const { categoryid, budgetlimit, budgetperiod, startdate, enddate } = req.body;
  const userid = req.session.userId;

  try {
    // Сохраняем бюджет в базу данных
    await pool.query(
      `INSERT INTO budgets (userid, categoryid, budgetlimit, budgetperiod, startdate, enddate)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [userid, categoryid, budgetlimit, budgetperiod, startdate, enddate]
    );

    res.redirect('/');
  } catch (err) {
    console.error('Ошибка при добавлении бюджета:', err);
    res.status(500).send('Ошибка сервера');
  }
});

// Страница транзакций с фильтром по дате
app.get('/transactions', requireLogin, async (req, res) => {
  try {
    const { startDate, endDate } = req.query;

    let query = `
      SELECT t.*, c.CategoryType 
      FROM Transactions t
      JOIN Categories c ON t.CategoryID = c.CategoryID
      WHERE t.userid = $1
    `;
    const params = [req.session.userId];

    if (startDate && endDate) {
      query += ' AND t.TransactionDate BETWEEN $2 AND $3';
      params.push(startDate, endDate);
    }

    query += ' ORDER BY t.TransactionDate DESC';

    const { rows: transactions } = await pool.query(query, params);

    // Разделяем транзакции на пополнения и расходы на основе transactiontype
    const income = transactions.filter(t => t.transactiontype === 'income');
    const expenses = transactions.filter(t => t.transactiontype === 'expense');

    res.render('transactions', {
      transactions,
      income,
      expenses,
      startDate: startDate || '',
      endDate: endDate || '',
    });
  } catch (err) {
    console.error('Ошибка при загрузке транзакций:', err);
    res.status(500).send('Ошибка сервера');
  }
});

// Страница регистрации
app.get('/register', (req, res) => {
  res.render('register');
});

// Обработка регистрации
app.post('/register', async (req, res) => {
  const { name, email, password } = req.body;

  try {
    // Хешируем пароль
    const hashedPassword = await bcrypt.hash(password, 10);

    // Сохраняем пользователя в базу данных
    const { rows } = await pool.query(
      'INSERT INTO users (name, email, password) VALUES ($1, $2, $3) RETURNING userid',
      [name, email, hashedPassword]
    );

    // Автоматически входим после регистрации
    req.session.userId = rows[0].userid;
    res.redirect('/');
  } catch (err) {
    console.error('Ошибка при регистрации:', err);
    res.status(500).send('Ошибка сервера');
  }
});

// Маршрут для отображения формы добавления транзакции
app.get('/add-transaction', requireLogin, async (req, res) => {
  try {
    // Получаем список категорий для выпадающего списка
    const { rows: categories } = await pool.query('SELECT * FROM categories');
    res.render('add-transaction', { categories });
  } catch (err) {
    console.error('Ошибка при загрузке категорий:', err);
    res.status(500).send('Ошибка сервера');
  }
});

// Обработка добавления транзакции
app.post('/add-transaction', requireLogin, async (req, res) => {
  const { transactiondate, amount, transactiontype, paymentmethod, notes } = req.body;
  const userid = req.session.userId;

  try {
    // Определяем categoryid в зависимости от типа транзакции
    let categoryid;
    if (transactiontype === 'income') {
      categoryid = 1; // ID категории для пополнений (замените на реальный ID)
    } else if (transactiontype === 'expense') {
      categoryid = 2; // ID категории для расходов (замените на реальный ID)
    } else {
      return res.status(400).send('Неверный тип транзакции');
    }

    // Сохраняем транзакцию в базу данных
    await pool.query(
      `INSERT INTO Transactions (userid, transactiondate, amount, categoryid, paymentmethod, notes, transactiontype)
       VALUES ($1, $2, $3, $4, $5, $6, $7)`,
      [userid, transactiondate, amount, categoryid, paymentmethod, notes, transactiontype]
    );

    res.redirect('/');
  } catch (err) {
    console.error('Ошибка при добавлении транзакции:', err);
    res.status(500).send('Ошибка сервера');
  }
});

// Страница входа
app.get('/login', (req, res) => {
  res.render('login');
});

// Обработка входа
app.post('/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    // Ищем пользователя по email
    const { rows } = await pool.query('SELECT * FROM users WHERE email = $1', [email]);

    if (rows.length === 0) {
      return res.status(400).send('Пользователь не найден');
    }

    // Проверяем пароль
    const validPassword = await bcrypt.compare(password, rows[0].password);
    if (!validPassword) {
      return res.status(400).send('Неверный пароль');
    }

    // Устанавливаем сессию
    req.session.userId = rows[0].userid;
    res.redirect('/');
  } catch (err) {
    console.error('Ошибка при входе:', err);
    res.status(500).send('Ошибка сервера');
  }
});

// Выход
app.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/login');
  });
});

// Запуск сервера
app.listen(port, () => {
  console.log(`Сервер запущен на http://localhost:${port}`);
});